#!/bin/bash -e

#PBS -l walltime=24:00:00,nodes=8:ppn=1

####
#
# Author: Ben Sanders (ben.sanders@nhs.net)
# Date:   2016-10-31
#
# This script processes exome sequence data as uploaded from the NextSeq
# It now includes bcl2fastq, so runs immediately after upload from NextSeq
#
# Generates fastq files from bcl, md5 files for each fastq, copies all into sample-specfic folders, and triggers CEP analysis scripts
# NOTE: IDs.txt must be present, and a copy of each analysis script
#       I should look into retrieving the scripts from a designated repository.
#       CEP scripts should also be updated, as they take some files from the WRGL folders, and should really be separate
#       Altough these could just be separate incidences of the same git repo.
#
###

cd $PBS_O_WORKDIR
module load bcl2fastq2/2.16

# check that all necessary files are present?

# this needs to change run by run. I wonder if it can be automated??
#TODO
runfolder="Data/Intensities/BaseCalls/TSO" # to complete
runID="" # to complete
pipelinescripts="/scratch/WCEP/PIPELINE"

# run bcl2fastq

bcl2fastq --no-lane-splitting --sample-sheet *SampleSheet*csv

# go to folder with fastqs
cd "$runfolder"

# generate md5 for each (looked for in variables making script)
for f in *.fastq.gz; do
        md5sum "$f" > "$f".md5
done

# return to root run folder
cd ../../../..
cp "$pipelinescripts"/*.sh .

# generate IDs.txt
cat *SampleSheet* | awk 'BEGIN{FS=",";IDs=0}{if (IDs == 1) print $1; if ($1 == "Sample_ID") IDs = 1}' | grep -v "^$" > IDs.txt

# copy fastq files to sample-specific folders
while read p; do
        mkdir "$p"
        cp "$runfolder"/"$p"* "$p"
        cp *CEP*.sh "$p"
done < IDs.txt

# delete raw data - must be before making variables
rm -rf Config
rm -rf Data
rm -rf Images
rm -rf InterOp
rm -rf Logs
rm -rf RTALogs
rm -rf Recipe
rm RTA*.txt RTA*.xml Run*.xml

# generate variables files for CEP scripts
./make_variables.sh "$runID"

# copy in other needed files
cp "$pipelinescripts"/TruSight_One_v1.1+-300bp.bed "$pipelinescripts"/PreferredTranscripts.txt .

# now trigger script 1 for each sample
while read p; do
        cd "$p"
        qsub 1_CEP_ReadAlignment.sh
        cd ..
done < IDs.txt
