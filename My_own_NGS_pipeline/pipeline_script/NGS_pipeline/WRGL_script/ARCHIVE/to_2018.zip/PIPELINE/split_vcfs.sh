##
# split filtered annotated VCF into individual sample VCFs for upload to Sapientia
# copy the BAM files into the for_upload folder
# TODO: start the upload automatically 
# TODO: get this actually working and don't just comment everything out!

module load jdk/1.8.0

# create the for_upload folder
mkdir for_upload

# load variables file
. *.variables

runID=`echo "${PWD##*/}"`

#split the VCF for each sample, and remove 0/0 genotypes (i.e. variants called in other samples)
while read sampleID; do
	echo "$runID"_"$sampleID"
	java -Xmx2000m -Djava.io.tmpdir=/scratch/WRGL/JavaTmp -jar /scratch/WRGL/software/GenomeAnalysisTK-3.7/GenomeAnalysisTK.jar \
	-T SelectVariants \
	-R /scratch/WRGL/bundle2.8/b37/human_g1k_v37.fasta \
	-V "$RunID"_Filtered.vcf \
	-o for_upload/"$sampleID"_TEMP.vcf \
	-sn "$sampleID"
	
	# remove 0/0 and ./. genotypes
	grep -v "0/0" for_upload/"$sampleID"_TEMP.vcf | grep -v "\./\." > for_upload/"$sampleID".vcf
	rm for_upload/"$sampleID"_TEMP.vcf for_upload/"$sampleID"_TEMP.vcf.idx

	# copy BAM and BAI files to for_upload, rename to just the sample ID
	cp "$sampleID"/"$runID"_"$sampleID".bai for_upload/"$sampleID".bai
	cp "$sampleID"/"$runID"_"$sampleID".bam for_upload/"$sampleID".bam
done < IDs.txt
