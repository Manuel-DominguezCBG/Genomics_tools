#!/bin/bash -e
#PBS -l walltime=01:00:00
#PBS -l nodes=1:ppn=16
#PBS -l mem=20GB
#PBS -W umask=0007
cd $PBS_O_WORKDIR

#Description: Nextera Pipeline
#Author: Matthew Lyon
#Status: Dev
#Updated: 30 November 2015, Ben Sanders
#Update note: Added umask to PBS settings, to allow multiple users to access output.
#Updated 20 Jan 2016, Reuben Pengelly
#Update note: improved multithreading with MPI due to poor speed of processing
#Updated 3 Mar 2016, Reuben Pengelly
#Update note: Changed to BWA-mem for alignment
#Updated 25 Oct 2016, Ben Sanders
#Update note: Removed previously commented out WRGL pipeline remnants (e.g. Novoalign call)

#Mode: BY_SAMPLE

module load bwa/0.7.5a

#load sample variables
. *.variables

#check FASTQ MD5sums
md5sum -c "$R1MD5Filename"
if [ $? -ne 0 ];then
   exit -1
fi

md5sum -c "$R2MD5Filename"
if [ $? -ne 0 ];then
   exit -1
fi

## Align reads with BWA-MEM
bwa mem \
-t 16 \
-M \
-R '@RG\tID:'"$RunID"'_'"$Sample_ID"'\tSM:'"$Sample_ID"'\tPL:'"$Platform"'\tLB:'"$ExperimentName" \
/scratch/WCEP/REF_GENOME/GRCh37 \
$R1Filename $R2Filename \
> "$RunID"_"$Sample_ID".sam

#start next job
qsub 2_CEP_IndelRealignment.sh
