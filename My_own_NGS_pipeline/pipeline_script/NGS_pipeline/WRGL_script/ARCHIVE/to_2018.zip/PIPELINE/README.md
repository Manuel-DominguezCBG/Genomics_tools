# WCEP scripts
Scripts for the analyis of WCEP exome samples on Iridis

## Dev scripts
* dev_bcl2fastq.sh
 * run after uploading raw NextSeq data. Does bcl2fastq conversion and splits files into sample folders. Then queues first analysis script.
* dev_low_throughput.sh
 * For the low-throughput exome service. Uses gene_list.txt to make a BED file for target regions, then intersects run VCF and coverage file to this.
 * This creates files that are small enough for download through the standard pipeline using GetData.
* compress_run.sh
 * To run after upload to Sapientia

## to do
* copy files for Sapientia upload
 * create a batch sftp file for hands-off transfer?
