#!/bin/bash -e
#PBS -l walltime=02:00:00
#PBS -l nodes=1:ppn=1
#PBS -l mem=4000mb
#PBS -W umask=0007
cd $PBS_O_WORKDIR

#Description: Nextera Pipeline
#Author: Matthew Lyon
#Status: Dev
#Updated: 30 November 2015, Ben Sanders
#Update note: Added umask to PBS settings, to allow multiple users to access output.
#Updated: 21 Jan 16, Reuben Pengelly
#Update note: Adjusted PBS parameters
#Mode: BY_COHORT

#Update: 2017-08-16 BS. Added bcftools call to split multiallelic variants and normalise variants
#Update: 2017-08-16 BS. Changed version of SNPEff to v4.3

module load jdk/1.8.0
module load samtools/1.3.2
module load bcftools/1.2.1

#load sample variables
. *.variables

refgenome=/scratch/WRGL/bundle2.8/b37/human_g1k_v37.fasta
dbsnpfile=/scratch/WRGL/bundle2.8/b37/dbsnp_138.b37.vcf

#merge calls from HC VCFs
java -Xmx2000m -Djava.io.tmpdir=/scratch/WRGL/JavaTmp -jar /scratch/WRGL/software/GenomeAnalysisTK-3.7/GenomeAnalysisTK.jar \
-T GenotypeGVCFs \
-R "$refgenome" \
--dbsnp "$dbsnpfile" \
-V VCFsforFiltering.list \
-L "$BEDFilename" \
-o "$RunID".vcf \
-dt NONE

# split multiallelic variants and normalise
bcftools norm -f "$refgenome" -m -any -O v -o "$RunID"_preNormalised.vcf "$RunID".vcf
bcftools norm -f "$refgenome" -m -any -O v -o "$RunID"_Normalised.vcf "$RunID"_preNormalised.vcf

# change 1/0 variant calls to 0/1
#NOTE: this may not be necessary for exoems, but if being pulled back for low-throughput analysis it will help with reporting module
sed -i s/"1\/0"/"0\/1"/g "$RunID"_Normalised.vcf

# set ./. genotypes to 0/0, again for low-throughput compatibility
sed -i s/"\.\/\."/"0\/0"/g "$RunID"_Normalised.vcf

# bcftools can replace NaN ("Not a Number" a valid Java numeric value) with nan (which isn't)
# replace to prevent downstream processing errors.
sed -i s/"nan"/"NaN"/g "$RunID"_Normalised.vcf

#extract SNPs
java -Xmx2000m -Djava.io.tmpdir=/scratch/WRGL/JavaTmp -jar /scratch/WRGL/software/GenomeAnalysisTK-3.7/GenomeAnalysisTK.jar \
-T SelectVariants \
-R "$refgenome" \
-V "$RunID"_Normalised.vcf \
-L "$BEDFilename" \
-o "$RunID"_SNPs.vcf \
-selectType SNP \
-dt NONE

#filter SNPs
java -Xmx2000m -Djava.io.tmpdir=/scratch/WRGL/JavaTmp -jar /scratch/WRGL/software/GenomeAnalysisTK-3.7/GenomeAnalysisTK.jar \
-T VariantFiltration \
-R "$refgenome" \
-V "$RunID"_SNPs.vcf \
-L "$BEDFilename" \
-o "$RunID"_SNPs_Filtered.vcf \
--filterExpression "QD < 2.0" \
--filterName "LowQD" \
--filterExpression "FS > 60.0" \
--filterName "SB" \
--filterExpression "MQ < 40.0" \
--filterName "LowMQ" \
--filterExpression "MQRankSum < -12.5" \
--filterName "MQRankSum" \
--filterExpression "ReadPosRankSum < -8.0" \
--filterName "ReadPosRankSum" \
-dt NONE

#extract INDELs
java -Xmx2000m -Djava.io.tmpdir=/scratch/WRGL/JavaTmp -jar /scratch/WRGL/software/GenomeAnalysisTK-3.7/GenomeAnalysisTK.jar \
-T SelectVariants \
-R "$refgenome" \
-V "$RunID"_Normalised.vcf \
-L "$BEDFilename" \
-o "$RunID"_INDELs.vcf \
-selectType INDEL \
-dt NONE

#filter INDELs
java -Xmx2000m -Djava.io.tmpdir=/scratch/WRGL/JavaTmp -jar /scratch/WRGL/software/GenomeAnalysisTK-3.7/GenomeAnalysisTK.jar \
-T VariantFiltration \
-R "$refgenome" \
-V "$RunID"_INDELs.vcf \
-L "$BEDFilename" \
-o "$RunID"_INDELs_Filtered.vcf \
--filterExpression "QD < 2.0" \
--filterName "LowQD" \
--filterExpression "FS > 200.0" \
--filterName "SB" \
--filterExpression "ReadPosRankSum < -20.0" \
--filterName "ReadPosRankSum" \
-dt NONE

#combine filtered variants
#NOTE: genotypemergeoption UNSORTED is a new requirement in v3.7, to match the default behaviour of v3.2
java -Xmx2000m -Djava.io.tmpdir=/scratch/WRGL/JavaTmp -jar /scratch/WRGL/software/GenomeAnalysisTK-3.7/GenomeAnalysisTK.jar \
-T CombineVariants \
-R "$refgenome" \
-o "$RunID"_Filtered.vcf \
--variant "$RunID"_SNPs_Filtered.vcf \
--variant "$RunID"_INDELs_Filtered.vcf \
-dt NONE \
--genotypemergeoption UNSORTED

#Annotate VCF using SNPEff4.3
java -Xmx4000m -Djava.io.tmpdir=/scratch/WRGL/JavaTmp -jar /scratch/WRGL/software/snpEff_v43/snpEff/snpEff.jar eff \
-v GRCh37.75 \
-noStats \
-no-downstream \
-no-intergenic \
-no-upstream \
-spliceSiteSize 10 \
-onlyTr "$PreferredTranscriptsFile" \
-noLog \
-formatEff \
"$RunID"_Normalised.vcf > "$RunID"_Filtered_Annotated.vcf

#calculate coverage
samtools depth -b "$BEDFilename" -q 20 -Q 40 -f BAMsforDepthAnalysis.list > "$RunID"_Coverage.txt

#write finish flag for download
echo > complete

#Set permissions for WCEP
chgrp -c wcep . ; chgrp -Rc wcep * ; chmod -c g+rwX . ; chmod -Rc g+rwX *
