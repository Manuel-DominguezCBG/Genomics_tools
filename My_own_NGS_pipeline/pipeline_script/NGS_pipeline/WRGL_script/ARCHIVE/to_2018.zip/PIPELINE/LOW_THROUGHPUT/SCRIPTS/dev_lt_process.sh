#!/bin/bash -e

#PBS -l walltime=02:00:00
#PBS -l nodes=1:ppn=1
#PBS -l mem=4000mb
#PBS -W umask=0007

cd $PBS_O_WORKDIR

##
## For processing WCEP runs to move samples to WRGL low throughput service.
## * Requires a samplesheet with the samples of interest (which is also needed locally, on the MiSeq, for GetData)
## * Requires a list of genes, to generate ROI bed file (should check that these are present on the capture kit, and use the same symbols)
## VCF and Coverage files are split by sample, then limited to genes of interest only
## VCF is then filtered against list of variants at >=2% AF in ExAC to remove common polys.
## Files are moved to WRGL folder and formatted ready for GetData download through MiSeq pipeline.
##

#####
#
# SECTION 1: INITIAL SETUP
#
#####

# load variables file
. *.variables

# load bedtools
module load bedtools/2.17.0
module load samtools/1.3.2
module load jdk/1.8.0
module load bcftools/1.2.1

# set up script variables
wrglpath=/scratch/WRGL
wceppath=/scratch/WCEP/Phase_2
runbed="$RunID"_ROIs.bed
namedbedfile=/scratch/WCEP/PIPELINE/LOW_THROUGHPUT/TruSight_Expanded_v2.0_with_names.bed
genelist=gene_list.txt
gatkpath=/scratch/WRGL/software/GenomeAnalysisTK-3.7/GenomeAnalysisTK.jar
refpath=/scratch/WRGL/bundle2.8/b37/human_g1k_v37.fasta
runvcf="$RunID"_Filtered.vcf
ltvcf="$runID"_LT.vcf
exacvcf=/scratch/WCEP/PIPELINE/LOW_THROUGHPUT/ExAC.r1.sites.vep_final.vcf

# remove BAMsForDepthAnalysisLT.list if it already exists (i.e. repeat analysis)
if [ -f BAMsforDepthAnalysisLT.list ]; then
	rm BAMsforDepthAnalysisLT.list
fi

#####
#
# SECTION 2: PREPARE REQUIRED FILES
#
#####

# make the list of sample IDs
# NOTE: May have to replace existing file with LT-specific file, or use a new name - to avoid clash with existing WCEP SampleSheet
cat *SampleSheet* | awk 'BEGIN{FS=",";IDs=0}{if (IDs == 1) print $1; if ($1 == "Sample_ID") IDs = 1}' | grep -v "^$" > IDs.txt

echo "Sample IDs extracted"

# need to make BED file for the run
# folder should have a gene list

# Gene list may be mix of comma delimited and new lines
# Replace all commas with newlines
# want to remove spaces too, in case of comma-space separation?
cat "$genelist" | sed s/","/"\n"/g > "$RunID"_gene_list.txt

echo "gene list processed"

# create a new BAMsforDepthAnalysis to avoid copying unwanted samples
while read p; do
        find `pwd` -name *"$p".bam >> BAMsforDepthAnalysisLT.list
done < IDs.txt

# Now lookup genes in TSO bed file (with names)
while read p; do
        grep "$p" "$namedbedfile" >> "$runbed".unsorted
done < "$RunID"_gene_list.txt

echo "unsorted list made"

# sort the bed file. Should be sorted already, but doesn't seem to be for some reason.
cat "$runbed".unsorted | sed -e s/"^X"/"23"/g -e s/"^Y"/"24"/g | sort -k1n -k2n  | sed -e s/"^23"/"X"/g -e s/"^24"/"Y"/g > "$runbed"

echo "ROIs for gene list found. BED file created"

#####
#
# SECTION 3: PROCESS FILES AND MOVE TO WRGL
#
#####

# create run folder in WRGL and copy files over
wrglfolder="$wrglpath"/"$RunID"
mkdir "$wrglfolder"

echo "WRGL run folder made"

# Extract only the samples of interest from run VCF
# use IDs.txt to generate GATK SelectVariants command
echo -ne java -jar "$gatkpath" -T SelectVariants -R "$refpath" -V "$runvcf" -o "$ltvcf""" "" > gatk_command.sh
while read p; do
        # have to force a space at the end using double-quotes
        echo -ne -sn "$p""" "" >> gatk_command.sh
done < IDs.txt
# make executable and run
chmod 770 gatk_command.sh
./gatk_command.sh

echo "Low-throughput samples selected"

# large files - process and copy
# intersect VCF
# -u flag prevents duplicate variants where bed regions overlap
# The Filtered file has already been normalised, so this doesn't need to be done here
bedtools intersect -header -u -a "$ltvcf" -b "$runbed" > "$wrglfolder"/"$RunID"_Filtered.vcf

java -Xmx4000m -Djava.io.tmpdir=scratch/WRGL/JavaTmp -jar /scratch/WRGL/software/snpEff_v43/snpEff/snpEff.jar \
-v GRCh37.75 \
-noStats \
-no-downstream \
-no-intergenic \
-no-upstream \
-spliceSiteSize 10 \
-onlyTr "$PreferredTranscriptsFile" \
-noLog \
-formatEff \
"$wrglfolder"/"$RunID"_Filtered.vcf > "$wrglfolder"/"$RunID"_Annotated.vcf

# remove variants with AC=0 (i.e. no variants called in these samples)
grep -v "AC=0" "$wrglfolder"/"$RunID"_Annotated.vcf > "$wrglfolder"/"$RunID"_Filtered_Annotated.vcf

# repeat samtools depth on only the samples of interest, using the gene list BED.
samtools depth -b "$runbed" -q 20 -Q 20 -f BAMsforDepthAnalysisLT.list > "$wrglfolder"/"$RunID"_Coverage.txt

echo "large files processed"

# smaller files can be copied without processing
cp complete BAMsforDepthAnalysis.list PreferredTranscripts.txt *.bed *.sh *.sh.* *SampleSheet* "$wrglfolder"
cp BAMsforDepthAnalysisLT.list "$wrglfolder"/BAMsforDepthAnalysis.list
touch "$wrglfolder"/"$RunID"_recalibration_plots.pdf

# copy sample folders and output files

while read p; do
	mkdir "$wrglfolder"/"$p"
	cp "$p"/*.sh.* "$wrglfolder"/"$p"
done < IDs.txt

echo "small files processed"

# chmod and chgrp the files as needed
chmod -R 770 "$wrglfolder"
chgrp -R wrgl "$wrglfolder"

echo "complete"

#####
#
# SECTION 4: TIDY TEMP FILES
#
#####

rm "$ltvcf" "$ltvcf".idx "$runbed" "$runbed".unsorted "$RunID"_gene_list.txt BAMsforDepthAnalysisLT.list gatk_command.sh

# Iridis output files are downloaded, but literally never used.
# Until this is removed from the pipeline, replace these ~200Mb files with empty files!
cd "$wrglfolder"
for p in `find . -name "*.sh.*"`; do
	rm "$p"
	touch "$p"
done

chmod -R 770 "$wrglfolder"
chgrp -R wrgl "$wrglfolder"
