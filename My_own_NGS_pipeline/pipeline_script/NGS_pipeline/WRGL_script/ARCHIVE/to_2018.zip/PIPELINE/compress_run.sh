#!/bin/bash -e
for d in `find . -type "d" | grep -v "^.$" | sed s/"\.\/"/""/g`; do
	tar -czvf "$d".tar.gz "$d"
	md5sum "$d".tar.gz > "$d".tar.gz.md5
	rm -rf "$d"
done
